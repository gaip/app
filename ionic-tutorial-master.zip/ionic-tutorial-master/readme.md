# Ionic Tutorial

In this tutorial, you learn how to build a native-like mobile application with Ionic and AngularJS. You build a Conference application that allows the attendees of the conference to browse through the list of sessions, and share information on Facebook.

Follow the step-by-step instructions available here: http://ccoenraets.github.io/ionic-tutorial/
